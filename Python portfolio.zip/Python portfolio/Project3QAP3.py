#Program used to keep track of car sales
#Zachary Hulan
#Oct 14th, 23 - Oct 

import datetime

#constants

LOW_LICENSE_FEE = 75
HIGH_LICENSE_FEE = 165
HST = 15
FINANCE_FEE = 39.99

custfname = "null"

while True:
    print()
    print("---------------------------------------------------------------------------------")
    print()


    #input

    custfname = input("Customer first name (type END to quit):  ").capitalize()

    #Will end program if user name is END (not a part of input)
    if custfname.upper() == "END":
        break

    #back to input
    custlname = input("Customer last name:  ").capitalize()
    custphonenum = str(input("Customer phone number:  "))
    platenum = str(input("Car plate number:  "))
    carmake = input("Enter car make:  ")
    carmodel = input("Enter car model:  ")
    modelyear = input("Year car model was released:  ")
    sellprice = int(input("Selling price:  "))
    tradeprice = int(input("Trade in:  "))
    salesname = input("Salesperson name:  ")



    #loops

    #Checks for input for the first name
    loopstop = False
    while loopstop == False:
        if custfname == "":
            print()
            print("Nothing entered for first name")
            print("TRY AGAIN")
            print()
            custfname = input("Customer first name:  ")
        else:
            loopstop = True


    #checks for input for the last name
    loopstop = False
    while loopstop == False:
        if custlname == "":
            print()
            print("Nothing entered for last name")
            print("TRY AGAIN")
            print()
            custlname = input("Customer last name:  ")
        else:
            loopstop = True


    #checks to see if a valid input is entered for the phone number
    loopstop = False
    while loopstop == False:
        if custphonenum == "":
            print()
            print("Nothing entered for phone number")
            print("TRY AGAIN")
            print()
            custphonenum = str(input("Customer phone number:  "))
        elif len(custphonenum) != 10:
            print()
            print("Phone number needs to be 10 digits")
            print("TRY AGAIN")
            print()
            custphonenum = str(input("Customer phone number:  "))
        else:
            loopstop = True


    #checks to see if a valid input is entered for the first half of the plate number
    loopstop = False
    while loopstop == False:
        if platenum == "":
            print()
            print("Nothing entered for the plate number")
            print("TRY AGAIN")
            print()
            platenum = str(input("Car plate number:  "))
            print()
            print("Car plate number must be 6 digits")
            print("TRY AGAIN")
            print()
            platenum = str(input("Car plate number:  "))
        else:
            loopstop = True


    #checks for valid input for the selling price
    loopstop = False
    while loopstop == False:
        if sellprice > 50000.00:
            print()
            print("Selling price cannot exceed 50,000.00")
            print("TRY AGAIN")
            print()
            sellprice = int(input("Selling price:  "))
        else:
            loopstop = True


    #checks for valid input for the trade in price
    loopstop = False
    while loopstop == False:
        if tradeprice > sellprice:
            print()
            print("Trade in cannot exceed original selling price")
            print("TRY AGAIN")
            print()
            tradeprice = int(input("Trade in:  "))
        else:
            loopstop = True


    #checks for input on salespersons name
    loopstop = False
    while loopstop == False:
        if salesname == "":
            print()
            print("Nothing entered for salesperson name")
            print("TRY AGAIN")
            print()
            salesname = input("Salesperson name:  ")
        else:
            loopstop = True



    #MATH

    atradep = sellprice - tradeprice

    #changes license fee based on price after trade
    if atradep > 5000.00:
        licensef = HIGH_LICENSE_FEE
    else:
        licensef = LOW_LICENSE_FEE

    #changes transfer fee based on selling price
    if sellprice > 20000.00:
        transferf = (sellprice * 1.6) / 100
    else:
        transferf = (sellprice * 1) / 100

    subtotal = atradep + licensef + transferf
    taxcost = (subtotal * 15) / 100
    total = subtotal + taxcost

    #grabs the date from the system
    date = datetime.datetime.now()
    dateplus30 = date + datetime.timedelta(days = 30)

    ##adjust to title case
    ##custfname
    ##custlname.title()





    #I have to get this ouside of the print() or it causes an error
    #getting certain characters from input for the output
    custfname0 = custfname[0]
    custlname0 = custlname[0]
    platenum4 = platenum[3]
    platenum5 = platenum[4]
    platenum6 = platenum[5]
    custphonenum7 = custphonenum[6]
    custphonenum8 = custphonenum[7]
    custphonenum9 = custphonenum[8]
    custphonenum10 = custphonenum[9]


    #FINAL OUTPUT

    print()
    print(f"          1         2         3         4         5         6         7")
    print(f"12345678901234567890123456789012345678901234567890123456789012345678901234567890")
    print()
    print(f"Honest Harry Car Sales                             Invoice Date:     {date.strftime('%m %d, %Y')}")
    print(f"Used Car Sale and Receipt                          Receipt No:       {custfname0}{custlname0}-{platenum4}{platenum5}{platenum6}-{custphonenum7}{custphonenum8}{custphonenum9}{custphonenum10}")
    print()
    sellpriceDsp = "${:,.2f}".format(sellprice)
    tradepriceDsp = "${:,.2f}".format(tradeprice)
    atradepDsp = "${:,.2f}".format(atradep)
    licensefDsp = "${:,.2f}".format(licensef)
    transferfDsp = "${:,.2f}".format(transferf)
    subtotalDsp = "${:,.2f}".format(subtotal)
    taxcostDsp = "${:,.2f}".format(taxcost)
    totalDsp = "${:,.2f}".format(total)
    print(f"                                                   Sale price:        {sellpriceDsp:>10s}")
    print(f"Sold to:                                           Trade Allowance:   {tradepriceDsp:>10s}")
    print("                                              ----------------------------------")
    print(f"     {custfname0}. {custlname}                                   Price after Trade: {atradepDsp:>10s}")
    print(f"     31 Johnson st                                 License Fee:       {licensefDsp:>10s}")
    print(f"     St. John's, NL A1A4E8                         Transfer Fee:      {transferfDsp:>10s}")
    print("                                              ----------------------------------")
    print(f"Car Details:                                       Subtotal:          {subtotalDsp:>10s}")
    print(f"                                                   HST:               {taxcostDsp:>10s}")
    print(f"     {modelyear:^5s} {carmake:^5s} {carmodel:^5s}                   ----------------------------------")
    print(f"                                                  Total sales price:  {totalDsp:>10s}")
    print(f"---------------------------------------------------------------------------------")
    print()
    print("                                   Financing     Total        Monthly")
    print("           # Years     # Payments     Fee        Price        Payment")
    print("          ------------------------------------------------------------")

    #loop for the payment schedule
    year = 0
    payments = 0
    financef = 0
    totalprice = 0
    monthlypay = 0

    while year < 5:
        year = year + 1
        payments = year * 12
        financef = year * FINANCE_FEE
        totalprice = total * financef
        monthlypay = totalprice / payments

        financefDsp = "${:,.2f}".format(financef)
        totalpriceDsp = "${:,.2f}".format(totalprice)
        monthlypayDsp = "${:,.2f}".format(monthlypay)
        if totalprice < 1000000.00:
            print(f"               {year}           {payments}   {financefDsp:>10s}   {totalpriceDsp:>10s}  {monthlypayDsp:>10s}")
        elif totalprice < 100000.00:
            print(f"               {year}           {payments}   {financefDsp:>10s}   {totalpriceDsp:>10s} {monthlypayDsp:>10s}")
        else:
            print(f"               {year}           {payments}   {financefDsp:>10s}   {totalpriceDsp:>8s}{monthlypayDsp:>10s}")

    print("          ------------------------------------------------------------")
    print(f"           Invoice date:  {date.strftime('%d-%m-%Y')}  First payment date:  {dateplus30.strftime('%d-%m-%Y')}")
    print(f"---------------------------------------------------------------------------------")
    print("                     Best used cars at the best prices!")
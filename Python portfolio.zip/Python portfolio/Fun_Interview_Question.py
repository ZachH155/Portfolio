#A loop that executes 100 times that will display something different based on whether its divisible by 5, 8, or both
#Oct 23rd, 23
#Zachary Hulan

loop_counter = 0
int(loop_counter)

while loop_counter <= 99:
    loop_counter = loop_counter + 1

    if loop_counter % 5 == 0 and loop_counter % 8 == 0:
        print("FizzBizz")
    elif loop_counter % 5 == 0:
        print("Fizz")
    elif loop_counter % 8 == 0:
        print("Bizz")
    else:
        print(loop_counter)

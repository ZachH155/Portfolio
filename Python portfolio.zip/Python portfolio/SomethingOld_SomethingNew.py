#creates a 4 youtube url for a youtube channel
#October 31st
#Group 11

#secrets is like random, except secrets uses the highest quality source from the operating system of the device
import secrets

#input employee name
name = input("Channel name: ")

#creates password for youtube channel
password = "" 
for i in range(3):
    password += secrets.choice("ABCD") + str(secrets.randbelow(9)) + str(secrets.randbelow(9)) + secrets.choice("ABCD")

#OUTPUT
print()
print("Username:  ", name)
print()
#genterates and prints employee code
print(f"Computer generated password:  {password}")
print()
print("Channel creator code (DO NOT SHARE): ", secrets.token_hex(30))
print()
print(f"Channel url: https://www.youtube.com/watch?v={secrets.token_urlsafe(25)}")
#A program that allows entry of proper information to create a receipt for the St. John’s Marina & Yacht Club
#Zachary Hulan
#Sept 26th, 23 - Sept 30th, 23

#Sorry about the late submittal, I finished this program and forgot to submit it


#constants
EVEN_SITE = 80
ODD_SITE = 120
ALT_MEMC = 5
WEEK_CLEANC = 50
VID_SURVC = 35
STANDARD_MEMC = 75
EXECUTIVE_MEMC = 150
PROCESSING_FEE = 59.99

#date literals
YEAR = 2023
MONTH = 10
DAY = 3

#needed for certain loops
loopstoppermem = False
loopstopperweek = False
loopstoppervideo = False


#input

sitenum = int(input("Site Number:  "))
memname = input("Member name:  ")
address = input("Street address:  ")
cityname = input("City name:  ")
provname = input("Province name:  ")
postcode = input("Postal code:  ")
hphonenum = input("Home phone number:  ")
cphonenum = input("Cell phone number:  ")
altmems = int(input("Extra members (family and friends who will be allowed access to the grounds):  "))
memtype = input("Membership Type (S or E):  ")
weekclean = input("Weekly site cleaning (Y or N)")
vidsurv = input("Video surveillance (Y or N)")




#loops

#loop that makes sure a valid site number is inputted
while sitenum < 1 or sitenum > 100:
    print()
    print("Site is invalid, must be from 1-100")
    print("TRY AGAIN")
    print()
    sitenum = int(input("Site Number:  "))


#Loop for making sure a valid member type is inputted
while loopstoppermem == False:
    if memtype == "S" or memtype == "s" or memtype == "E" or memtype == "e":
        loopstoppermem = True
    else:
         print()
         print("Membership type invalid")
         print("TRY AGAIN")
         print()
         memtype = input("Membership Type (S or E):  ")

#Loop for making sure a valid answer is inputted for weekly cleaning
while loopstopperweek == False:
    if weekclean == "Y" or weekclean == "y" or weekclean == "N" or weekclean == "n":
        loopstopperweek = True
    else:
         print()
         print("Answer for weekly cleaning is invalid")
         print("TRY AGAIN")
         print()
         weekclean = input("Weekly site cleaning (Y or N)")


#Loop for making sure a valid answer is inputted for video surveillance
while loopstoppervideo == False:
    if vidsurv == "Y" or vidsurv == "y" or vidsurv == "N" or vidsurv == "n":
        loopstoppervideo = True
    else:
         print()
         print("Answer for weekly cleaning is invalid")
         print("TRY AGAIN")
         print()
         vidsurv = input("Video surveillance (Y or N)")



#if statements

#checks if site number is even or odd and changes cost accordingly
if (sitenum % 2) == 0:
   memscost = int(altmems * ALT_MEMC)
   sitecost = EVEN_SITE + memscost
else: 
    memscost = int(altmems * ALT_MEMC)
    sitecost = ODD_SITE + memscost
    
#checks for extra charges and adds them
#weekly cleaning
extracost = 0
if weekclean == "Y" or weekclean == "y":
    extracost = extracost + WEEK_CLEANC
    weeklycleaning = "Yes"
else: weeklycleaning = "No"
#video survallince
if vidsurv == "Y" or vidsurv == "y":
    extracost = extracost + VID_SURVC
    videosurvallince = "Yes"
else: videosurvallince = "No"

#monthly dues
if memtype == "S" or memtype == "s":
    monthlydues = STANDARD_MEMC
    membershiptype = "Standard"
else:
    monthlydues = EXECUTIVE_MEMC
    membershiptype = "Executive"



#MATH

subtotal = sitecost + extracost
taxcost = 15 * subtotal / 100
totmonthc = subtotal + taxcost
totmonthf = totmonthc + monthlydues
totyearf = totmonthf * 12
monthpay = (totyearf + PROCESSING_FEE) / 12
cancelf = (60 * sitecost) / 100






#output FINAL

print()
print()
print(f"     St. John’s Marina & Yacht Club")
print(f"         Yearly Member Receipt")
print(f"________________________________________")
print(f"")
print(f"Client Name and Address:")
print(f"")
print(f"{memname}")
print(f"{address} {cityname},")
print(f"{provname} {postcode}")
print(f"")
print(f"Phone: {hphonenum} (H)")
print(f"       {cphonenum} (C)")
print(f"")
print(f"Site #: {sitenum:>3d}    Member type:   {membershiptype:>9s}")
print(f"")
print(f"Alternate members:                  {altmems:>3d}")
print(f"Weekly site cleaning:               {weeklycleaning:>3s}")
print(f"Video surveillance:                 {videosurvallince:>3s}")
print(f"")
sitecostDsp = "${:,.2f}".format(sitecost)
extracostDsp = "${:,.2f}".format(extracost)
print(f"Site charges:                 {sitecostDsp:>9s}")
print(f"Extra charges:                {extracostDsp:>9s}")
print(f"                              ---------")
subtotalDsp = "${:,.2f}".format(subtotal)
taxcostDsp = "${:,.2f}".format(taxcost)
print(f"Subtotal:                     {subtotalDsp:>9s}")
print(f"Sales Tax:                    {taxcostDsp:>9s}")
print(f"                              ---------")
totmonthcDsp = "${:,.2f}".format(totmonthc)
monthlyduesDsp = "${:,.2f}".format(monthlydues)
print(f"Total monthly charges:        {totmonthcDsp:>9s}")
print(f"Monthly dues:                 {monthlyduesDsp:>9s}")
print(f"                              ---------")
totmonthfDsp = "${:,.2f}".format(totmonthf)
totyearfDsp = "${:,.2f}".format(totyearf)
print(f"Total monthly fees:           {totmonthfDsp:>9s}")
print(f"Total yearly fees:            {totyearfDsp:>9s}")
print(f"")
monthpayDsp = "${:,.2f}".format(monthpay)
print(f"Monthly payment:              {monthpayDsp:>9s}")
print(f"________________________________________")
print(f"Issued: {YEAR}-{MONTH}-0{DAY}")
print(f"HST RegNo: 549-33-5849-4720-9885")
print(f"")
cancelfDsp = "${:,.2f}".format(cancelf)
print(f"Cancellation Fee:             {cancelfDsp:>9s}")
print(f"")
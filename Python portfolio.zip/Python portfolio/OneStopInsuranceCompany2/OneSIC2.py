#A program to process data files and create reports for the OSIC
#Zachary Hulan
#Dec 3rd - 7th

#I had to edit Policies.dat to add a "Y" and "N" at the end of every list so that I could make this work
#since "==" checks for the same item in memory and not if the two variables are actually the same

import datetime as dt



#opens the data files and reads them to create a list
OSICDef = open("OneStopInsuranceCompany2/OSICDef.dat", "r")
listOSICDef = OSICDef.read().splitlines()
OSICDef.close()

Policies = open("OneStopInsuranceCompany2/Policies.dat", "r")
listPolicies = Policies.read().splitlines()
Policies.close()


#def functions
def Discount(Value1, Value2):
    return Value1 * Value2


#CONSTANTS
NEXT_POLICY_NUM = listOSICDef[0]
FIRST_CAR_PREMIUM = float(listOSICDef[1])
ADDITIONAL_CAR_DISCOUNT = float(listOSICDef[2])
EXTRA_LIABLITY = float(listOSICDef[3])
GLASS_COVERAGE = float(listOSICDef[4])
LOANER_CAR_COST = float(listOSICDef[5])
HST = listOSICDef[6]
MONTHLY_PAYMENT_PROCESSING_FEE = listOSICDef[7]


#grabs the date from the system
date = dt.datetime.now()

#OUTPUT
print(f"1234567890123456789012345678901234567890123456789012345678901234567890123")
print()
print(f"ONE STOP INSURANCE COMPANY")
print(f"POLICY LISTING AS OF {date.strftime('%d-%m-%Y')}")
print()
print(f"POLICY CUSTOMER              POLICY     INSURANCE   EXTRA      TOTAL")
print(f"NUMBER NAME                   DATE       PREMIUM    COSTS     PREMIUM")
print(f"=========================================================================")


#loop that repeats for every value in the list
TotalPolicies = 0
TotalinsurancePremium = 0
TotalextraCosts = 0
TotaltotalPremium = 0
for value in listPolicies:
    TotalPolicies = TotalPolicies + 1

    #splits Policies.dat into seperate lists every loop
    listPolicies2 = value.split(",")
    
    p0 = listPolicies2[0]
    p1 = listPolicies2[1]
    p2 = listPolicies2[2]
    p3 = listPolicies2[3]
    p4 = listPolicies2[4]
    p5 = listPolicies2[5]
    p6 = listPolicies2[6]
    p7 = listPolicies2[7]
    p8 = listPolicies2[8]
    p9 = int(listPolicies2[9])
    p10 = listPolicies2[10]
    p11 = listPolicies2[11]
    p12 = listPolicies2[12]
    p13 = listPolicies2[13]
    p14 = listPolicies2[14]
    Yes = listPolicies2[15]
    No = listPolicies2[16]

    p23 = p2 + p3


    #coverage
    if p9 > 1:
        additionalCarpremium = Discount(FIRST_CAR_PREMIUM, ADDITIONAL_CAR_DISCOUNT)
        insurancePremium = (additionalCarpremium * p9) + FIRST_CAR_PREMIUM
    else:
        insurancePremium = FIRST_CAR_PREMIUM
    

    #extra costs
    extraCosts = 0
    if p10 == Yes:
        extraCosts = extraCosts + EXTRA_LIABLITY
    
    if p11 == Yes:
        extraCosts = extraCosts + GLASS_COVERAGE

    if p12 == Yes:
        extraCosts = extraCosts + LOANER_CAR_COST

    
    totalPremium = insurancePremium + extraCosts

    #adding the totals together for printing at the very end
    TotalinsurancePremium = TotalinsurancePremium + insurancePremium
    TotalextraCosts = TotalextraCosts + extraCosts
    TotaltotalPremium = TotaltotalPremium + totalPremium

    #OUTPUT
    insurancePremiumDsp = "${:,.2f}".format(insurancePremium)
    extraCostsDsp = "${:,.2f}".format(extraCosts)
    totalPremiumDsp = "${:,.2f}".format(totalPremium)

    print(f"{p0:<6s}{p23:<19s}{p1:^15s}{insurancePremiumDsp:^10s}{extraCostsDsp:^10s}{totalPremiumDsp:^12s}")
    

print(f"=========================================================================")
TotalinsurancePremiumDsp = "${:,.2f}".format(TotalinsurancePremium)
TotalextraCostsDsp = "${:,.2f}".format(TotalextraCosts)
TotaltotalPremiumDsp = "${:,.2f}".format(TotaltotalPremium)
print(f"Total policies: {TotalPolicies:<23d}{TotalinsurancePremiumDsp:^12s}{TotalextraCostsDsp:^10s}{TotaltotalPremiumDsp:^10s}")

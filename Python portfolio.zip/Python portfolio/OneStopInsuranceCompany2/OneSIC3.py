#A program to process data files and create reports for the OSIC
#Zachary Hulan
#Dec 3rd - 8th

#I had to edit Policies.dat to add "Monthly" and "Downpay" at the end of every list so that I could make this work
#since "==" checks for the same item in memory and not if the two variables are actually the same

import datetime as dt



#opens the data files and reads them to create a list
OSICDef = open("OneStopInsuranceCompany2/OSICDef.dat", "r")
listOSICDef = OSICDef.read().splitlines()
OSICDef.close()

Policies = open("OneStopInsuranceCompany2/Policies.dat", "r")
listPolicies = Policies.read().splitlines()
Policies.close()


#def functions
def Discount(Value1, Value2):
    return Value1 * Value2


#CONSTANTS
NEXT_POLICY_NUM = listOSICDef[0]
FIRST_CAR_PREMIUM = float(listOSICDef[1])
ADDITIONAL_CAR_DISCOUNT = float(listOSICDef[2])
EXTRA_LIABLITY = float(listOSICDef[3])
GLASS_COVERAGE = float(listOSICDef[4])
LOANER_CAR_COST = float(listOSICDef[5])
HST = float(listOSICDef[6])
MONTHLY_PAYMENT_PROCESSING_FEE = float(listOSICDef[7])


#grabs the date from the system
date = dt.datetime.now()

#OUTPUT
print()
print(f"123456789012345678901234567890123456789012345678901234567890123456789012345")
print()
print(f"ONE STOP INSURANCE COMPANY")
print(f"POLICY LISTING AS OF {date.strftime('%d-%m-%Y')}")
print()
print(f"POLICY CUSTOMER             TOTAL                TOTAL     DOWN     MONTHLY")
print(f"NUMBER NAME                PREMIUM      HST      COST     PAYMENT   PAYMENT")
print(f"===========================================================================")


#loop that repeats for every value in the list
TotalPolicies = 0
TotalinsurancePremium = 0
TotalextraCosts = 0
TotaltotalPremium = 0
TotaltotalCost = 0
Totalhst = 0
TotaldownPayment = 0
TotalmonthlyPayment = 0
for value in listPolicies:
    

    #splits Policies.dat into seperate lists every loop
    listPolicies2 = value.split(",")
    
    p0 = listPolicies2[0]
    p1 = listPolicies2[1]
    p2 = listPolicies2[2]
    p3 = listPolicies2[3]
    p4 = listPolicies2[4]
    p5 = listPolicies2[5]
    p6 = listPolicies2[6]
    p7 = listPolicies2[7]
    p8 = listPolicies2[8]
    p9 = int(listPolicies2[9])
    p10 = listPolicies2[10]
    p11 = listPolicies2[11]
    p12 = listPolicies2[12]
    p13 = listPolicies2[13]
    p14 = float(listPolicies2[14])
    Yes = listPolicies2[15]
    No = listPolicies2[16]
    Monthly = listPolicies2[17]
    DownPay = listPolicies2[18]


    p23 = p2 + p3


    #coverage
    if p9 > 1:
        additionalCarpremium = Discount(FIRST_CAR_PREMIUM, ADDITIONAL_CAR_DISCOUNT)
        insurancePremium = (additionalCarpremium * p9) + FIRST_CAR_PREMIUM
    else:
        insurancePremium = FIRST_CAR_PREMIUM
    

    #extra costs
    extraCosts = 0
    if p10 == Yes:
        extraCosts = extraCosts + EXTRA_LIABLITY
    
    if p11 == Yes:
        extraCosts = extraCosts + GLASS_COVERAGE

    if p12 == Yes:
        extraCosts = extraCosts + LOANER_CAR_COST

    
    #final calculations for output
    totalPremium = insurancePremium + extraCosts
    tax = Discount(totalPremium, HST)
    totalCost = totalPremium + tax
    monthlyPayment = ((totalCost + MONTHLY_PAYMENT_PROCESSING_FEE) - p14) / 12

    #adding the totals together for printing at the very end
    TotalinsurancePremium = TotalinsurancePremium + insurancePremium
    TotalextraCosts = TotalextraCosts + extraCosts
    TotaltotalPremium = TotaltotalPremium + totalPremium
    TotaltotalCost = TotaltotalCost + totalCost
    Totalhst = Totalhst + tax
    TotaldownPayment = TotaldownPayment + p14
    TotalmonthlyPayment = TotalmonthlyPayment + monthlyPayment

    #OUTPUT
    taxDsp = "${:,.2f}".format(tax)
    totalCostDsp = "${:,.2f}".format(totalCost)
    totalPremiumDsp = "${:,.2f}".format(totalPremium)
    downPaymentDsp = "${:,.2f}".format(p14)
    monthlyPaymentDsp = "${:,.2f}".format(monthlyPayment)


    #makes sure the payment is monthly or downpay
    if p13 == Monthly or p13 == DownPay:
        TotalPolicies = TotalPolicies + 1
        print(f"{p0:<6s}{p23:<18s}{totalPremiumDsp:^13s}{taxDsp:^10s}{totalCostDsp:^10s}{downPaymentDsp:^9s}{monthlyPaymentDsp:^12s}")
    

print(f"===========================================================================")
TotaltotalPremiumDsp = "${:,.2f}".format(TotaltotalPremium)
TotaltotalCostDsp = "${:,.2f}".format(TotaltotalCost)
TotalhstDsp = "${:,.2f}".format(Totalhst)
TotaldownPaymentDsp = "${:,.2f}".format(TotaldownPayment)
TotalmonthlyPaymentDsp = "${:,.2f}".format(TotalmonthlyPayment)
print(f"Total policies: {TotalPolicies:<8d}{TotaltotalPremiumDsp:^13s}{TotalhstDsp:^10s}{TotaltotalCostDsp:^10s}{TotaldownPaymentDsp:^9s}{TotalmonthlyPaymentDsp:^10s}")





#constants
rent_per_dayrate = 55
km_travelrate = 24
insurance = 14

#defines function that calculates discount
def discount(percent, whole):
    return (percent * whole) / 100.0



#customer info
customername = input("Enter customer's full name:  ")
phonenum = input("Enter customer's phone number:  ")
dayzrented = input("Length of rental period:  ")
rentedodo = input("Odometer reading on rental day:  ")
returnodo = input("Odometer reading on return day:  ")



#MATH!!1!11!1!11
tKt = int(returnodo) - int(rentedodo)
rentcost = int(dayzrented) * int(rent_per_dayrate)
mileagecost = tKt * km_travelrate
insureancecost = insurance * int(dayzrented)



#discount calculations
rentdis = discount(10, rentcost)
mileagedis = discount(25, mileagecost)
totaldis = rentdis + int(mileagedis)



#total rental cost
totalrc = (rentcost + mileagecost + int(insureancecost)) - totaldis



#HST
hst = discount(15, totalrc)
finalinvoice = totalrc + hst




#output

print("")
print("Name: ", customername)
print("Customer Phone: ", phonenum)
print("Days rented: ", dayzrented)
print("Odometer on rental day: ", rentedodo)
print("Odometer on day returned: ", returnodo)
print("")

print("-----------------------------------------------------------")

print("")
print("Mileage: ", mileagecost, "               Total Km traveled: ", tKt)
print("Insureance: ", insureancecost)
print("")

print("-----------------------------------------------------------")

print("")
print("Total rental cost: ", totalrc, "  Total Discount:  -", totaldis)
print("")

print("-----------------------------------------------------------")

print("")
print("HST: ", hst)
print("")
print("Final Invoice: ", finalinvoice)
print("")



fetch("./data.json")
    .then(response => response.json())
    .then(response => {
        response.forEach(entry => {console.log(entry)})
    })
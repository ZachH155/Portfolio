
//1
let label = "keyincollege";
let tld = "ca";
let domainName = label + "." + tld;
console.log(domainName);

//2
if (domainName == "keyincollege.ca") {
    var isKeyin = true;   
}
else {
    var isKeyin = false;
}
console.log(isKeyin);

//3
let isNotKeyin = !isKeyin;
console.log(isNotKeyin);

//4
let byte1 = 181
let byte2 = 243
let byte3 = 4
let byte4 = 6

//5
let ipAddress = byte1 + "." + byte2 + "." + byte3 + "." + byte4
console.log(ipAddress)

//6
function multTable(n) {
    for(let i = 1; i <= 10; i++) {
        console.log(`${n} * ${i} = ${n * i}`);
    }
};
multTable(15);

//7
function evenOdd100() {
    for(let i = 1; i <= 100; i++) {
        if (i % 2 != 0) {
            console.log(`Odd ${i}`);
        }
        else{
            console.log(`Even ${i}`);
        }
    }
};
evenOdd100();

//8

function evenSum100() {
    let sum = 0
    for(let i = 1; i <= 100; i++) {
        if (i % 2 == 0) {
            sum = sum + i
        }
    }
console.log(sum);
};
evenSum100();

//9
function isPerfectNumber(n) { 
	let sum = 0; 
	for (let i = 1; i < n; i++) { 
		if (n % i === 0) { 
			sum += i; 
		} 
	} 

	const isPerfect = sum === n; 

	// Output the result 
	if (isPerfect) { 
		console.log(`${n} is perfect`); 
	}
	else {
        console.log(`${n} is not perfect`);
    }
} ;

isPerfectNumber(6)

//10
function isPrimeNumber(n) {
    for (let i = 2; i < n; i++) {
        if (n % i == 0) {
            console.log(`${n} is not prime`);
            break;
        }
        else {
            console.log(`${n} is prime`);
            break;
        }
    }
};
isPrimeNumber(5)